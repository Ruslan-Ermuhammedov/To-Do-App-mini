export const house = [

    {
        rooms: 5,
        location: 'Bektemir',
        price: 120000
    }
    ,
    {
        rooms: 1,
        location: 'Mirobod',
        price: 60200
    }
    ,
    {
        rooms: 2,
        location: 'Mirzo-Ulug`bek',
        price: 67000
    }
    ,
    {
        rooms: 3,
        location: 'Sergeli',
        price: 87000
    }
    ,
    {
        rooms: 4,
        location: 'Shayxantaxur',
        price: 72000
    }
    ,
    {
        rooms: 5,
        location: 'Yunusobod',
        price: 56000
    }
    ,
    {
        rooms: 5,
        location: 'Chilonzor',
        price: 55000
    }
    ,
    {
        rooms: 2,
        location: 'Olmazor',
        price: 123000
    }
    ,
    {
        rooms: 3,
        location: 'Bektemir',
        price: 98000
    }
    ,
    {
        rooms: 5,
        location: 'Mirobod',
        price: 41000
    }
    ,
    {
        rooms: 1,
        location: 'Mirzo-Ulug`bek',
        price: 105000
    }
    ,
    {
        rooms: 1,
        location: 'Sergeli',
        price: 94000
    }
    ,
    {
        rooms: 2,
        location: 'Shayxantaxur',
        price: 95000
    }
    ,
    {
        rooms: 4,
        location: 'Yunusobod',
        price: 42000
    }
    ,
    {
        rooms: 2,
        location: 'Chilonzor',
        price: 55000
    }
    ,
    {
        rooms: 5,
        location: 'Olmazor',
        price: 76000
    }
    ,
    {
        rooms: 3,
        location: 'Bektemir',
        price: 92000
    }
    ,
    {
        rooms: 2,
        location: 'Mirobod',
        price: 42000
    }
    ,
    {
        rooms: 1,
        location: 'Mirzo-Ulug`bek',
        price: 120000
    }
    ,
    {
        rooms: 5,
        location: 'Sergeli',
        price: 107000
    }
    ,
    {
        rooms: 2,
        location: 'Shayxantaxur',
        price: 92000
    }
]